package com.jspiders.hospital_app;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostpitalAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(HostpitalAppApplication.class, args);
	}
}
